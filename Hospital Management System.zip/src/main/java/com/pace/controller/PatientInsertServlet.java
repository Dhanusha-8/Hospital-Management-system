package com.pace.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pace.bean.Patient;
import com.pace.dao.PatientDAO;



/**
 * Servlet implementation class PatientInsertServlet
 */
public class PatientInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PatientDAO patientDao=new PatientDAO();
		Patient patient=new Patient();
		int rows=0;
		int id;
		String name;
		long mobile;
		String address;
		id = Integer.parseInt(request.getParameter("id"));
		name=request.getParameter("name");
		mobile=Long.parseLong(request.getParameter("mobile"));
		address=request.getParameter("address");
		//make the pojo ready with data
		patient.setId(id);
		patient.setName(name);
		patient.setMobile(mobile);
		patient.setAddress(address);
		//pojo is ready with data
		System.out.println(patient.getName());
		try {
			rows=patientDao.insertPatientDetails(patient);
			
		}catch(Exception e) {
			System.err.println("patient data cannot inserted!");
		}
		if(rows==1) {
			System.out.println("patient data successfully inserted!");
			RequestDispatcher dis =request.getRequestDispatcher("insertSuccess.html");
			dis.forward(request, response);
		}else {
			System.out.println("patient data could not insert");
		}
		
		
	}
	}


