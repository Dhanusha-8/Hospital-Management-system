package com.pace.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pace.bean.Patient;
import com.pace.service.PatientServiceProvider;


/**
 * Servlet implementation class PatientServlet
 */
public class PatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public PatientServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Patient patient=new Patient();
		ArrayList<Patient>patientList=new ArrayList<Patient>();
		PatientServiceProvider patientServiceProvider=new PatientServiceProvider();
		try {
			patientList=patientServiceProvider.getPatientService();
			HttpSession session=request.getSession();
			session.setAttribute("patientlist",patientList);
			RequestDispatcher dis=request.getRequestDispatcher("showPatientDetails.jsp");
			dis.forward(request,response);
		}catch(Exception e) {
			System.out.println("Patient data could not found");
		}
	}
	}


