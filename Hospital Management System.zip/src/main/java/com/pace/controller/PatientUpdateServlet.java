package com.pace.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pace.dao.PatientDAO;


/**
 * Servlet implementation class PatientUpdateServlet
 */
public class PatientUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PatientDAO patientDao=new PatientDAO();
		
		boolean rows=false;
		int id;
		
		id=Integer.parseInt(request.getParameter("id"));
		
		try {
			rows =patientDao.updatePatient(id);
		}catch(Exception e) {
			System.err.println("Patient data could not updated");
		}
		if(rows==true) {
			System.out.println("Patient data successfully updated");
		}else {
			System.out.println("Patient data cannot updated");
		}
		RequestDispatcher dis =request.getRequestDispatcher("updateSuccess.html");
		dis.forward(request, response);
	
	}

}
