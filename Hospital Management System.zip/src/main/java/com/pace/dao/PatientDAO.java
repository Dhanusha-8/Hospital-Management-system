package com.pace.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import java.util.Scanner;
import com.pace.bean.Patient;
import com.pace.helper.DbConnector;

public class PatientDAO {
	private Connection connection = null;
	private PreparedStatement pStatement = null;
	private ResultSet resultSet = null;
	ArrayList<Patient> patientList = null;
	private static String patientQry = "select * from patient";
	
	//get patient data
	public ArrayList<Patient> getPatients() throws ClassNotFoundException, SQLException {
		try {
			connection = DbConnector.createConnection();
			pStatement = connection.prepareStatement(patientQry);
			resultSet = pStatement.executeQuery();
			Patient patient;
			patientList = new ArrayList<Patient>();
			while(resultSet.next()) {
				String patientId;
				String password;
				String patientName;
				long mobile;
				String address;
				patient = new Patient();
				patientId = resultSet.getString(1);
				password = resultSet.getString(2);
				patientName = resultSet.getString(3);
				mobile = resultSet.getLong(4);
				address = resultSet.getString(5);
				patient.setId(patientId);
				patient.setName(patientName);
				patient.setMobile(mobile);
				patient.setAddress(address);
				patientList.add(patient);
				patient = null;
			}
		}catch (SQLException sqlex) {
			
		}finally {
			DbConnector.closeConnection();
		}
		return patientList;
	}
	//show patient list
	public void showPatientList(ArrayList<Patient> patientList2) {
		System.out.println("In DAO layer");
		for(Patient patient : patientList2) {
			System.out.print(patient.getId());
			System.out.print("\t" + patient.getName());
			System.out.print("\t" + patient.getMobile());
			System.out.println("\t" + patient.getAddress());
		}
	}
	//insert patient data
	public int insertPatientDetails(Patient patient) throws ClassNotFoundException,SQLException {
		connection = DbConnector.createConnection();
		String insQry = "insert into patient values(?,?,?,?)";
		pStatement = connection.prepareStatement(insQry);
		pStatement.setInt(1,patient.getId());
		pStatement.setString(2,patient.getName());
		pStatement.setLong(3,patient.getMobile());
		pStatement.setString(4,patient.getAddress());
		
		int rows=pStatement.executeUpdate();
		System.out.println(rows +" Rows Inserted!");
		DbConnector.closeConnection();
		return rows;
	}
	//delete patient
	public boolean deletePatient(int id) throws SQLException, ClassNotFoundException {
		pStatement = null;
		connection = DbConnector.createConnection();
		String delQry="delete from patient where id=?";
		pStatement = connection.prepareStatement(delQry);
		pStatement.setInt(1, id);
		int rows = pStatement.executeUpdate();
		boolean isDelete = true;
		if (rows != 0) { // if rows is non-zero, it is deleted
			isDelete = true; // status of deletion
		} else {
			isDelete = false; // status of deletion
		}
		DbConnector.closeConnection();
		return isDelete;
	}
	//updating patient
	public boolean updatePatient(int id) throws SQLException, ClassNotFoundException {
		pStatement = null;
		connection = DbConnector.createConnection();
		String updQry="update patient set id = id + 1 where id=?" ;
		pStatement = connection.prepareStatement(updQry);
		pStatement.setInt(1, id);
		int rows = pStatement.executeUpdate();
		boolean isUpdate = true;
		if (rows != 0) { // if rows is non-zero, it is deleted
			isUpdate = true; // status of deletion
		} else {
			isUpdate = false; // status of deletion
		}
		DbConnector.closeConnection();
		return isUpdate;
	}

}//end of DAO
