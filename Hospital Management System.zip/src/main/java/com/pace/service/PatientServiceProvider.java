package com.pace.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.pace.bean.Patient;
import com.pace.dao.PatientDAO;



public class PatientServiceProvider {
	
	ArrayList<Patient> patientList = new ArrayList<Patient>();
	PatientDAO patientDAO = new PatientDAO();
	
	public ArrayList<Patient> getPatientService() throws ClassNotFoundException, SQLException {
		patientList = patientDAO.getPatients();
		return patientList;
	}
	
	public void showPatientService(ArrayList<Patient> patientList) throws ClassNotFoundException, SQLException {

		System.out.println("In service layer ");
		patientList = patientDAO.getPatients();
		patientDAO.showPatientList(patientList);
	}
	
	public void insertPatientService(Patient patient) throws ClassNotFoundException, SQLException {
		patientDAO.insertPatientDetails(patient);
	}
	
	public void deletePatientService(int id) throws ClassNotFoundException, SQLException {
		boolean isPatientDeleted = patientDAO.deletePatient(id);
		if (isPatientDeleted == true) {
			System.out.println("Patient with id " + id + " was deleted");
		} else {
			System.out.println("Patient with id " + id + " is unavailable");
		}
	}
	public void updatePatientService(int id) throws ClassNotFoundException, SQLException {
		boolean isPatientUpdated = patientDAO.updatePatient(id);
		// boolean isBookDeleted = bookDAO.updateBook(id);
		if (isPatientUpdated == true) {
			System.out.println("Patient with id " + id + " was updated!");
		} else {
			System.out.println("Patient with id " + id + " is unavailable!");
		}
	}
	

}
